#!/usr/bin/zsh

echo 'source /vagrant_data/powerlevel9k.zsh-theme' > ~/.zshrc
